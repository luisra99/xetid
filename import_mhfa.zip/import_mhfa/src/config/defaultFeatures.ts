export const defaultAccessProfile = {
  '/inicio': [],
  '/acerca': [],
  '/preguntas': [],
  '/terminos': [],
  '/politicas': [],
};
export const defaultMenu = {
  '/inicio': { title: 'Inicio', icon: null },
  '/acerca': { title: 'Acerca de...', icon: null },
  '/preguntas': { title: 'Preguntas Frecuentes', icon: null },
  '/terminos': { title: '', icon: null },
  '/politicas': { title: '', icon: null },
};
