type Notifications = {
  options: any;
  maxSnack: number;
};

export type { Notifications };
