import type { Notifications } from './types';

import isMobile from '@/utils/is-mobile';

const title = 'React PWA Template';

const email = 'xetid@xetid.cu';

const repository = 'https://xetid.cu';

const apiScope=import.meta.env.VITE_APP_MODE === 'dev'?'/gw-dev/':'/gw/';
const tokenEndpoint='token';
const userInfo='getinfo';
const challenge='challenge';
const identity='https://identity.enzona.net/';
const mode: boolean=import.meta.env.VITE_APP_MODE === 'dev' ? true : false;

const profileConfig: { key: string; label: string; check?: any }[] = [
  { key: 'PI', label: 'Datos del proveedor de identidad', },
  { key: 'ESTRUCTURA', label: 'Rol y permisos', check: 'El usuario no tiene estructura asociada, contacte con el administrador de sistema' },
  { key: 'APP', label: 'Datos específicos' },
];

const messages = {
  app: {
    crash: {
      title: 'Ups... Lo sentimos, algo fue mal con la aplicación. Usted puede:',
      options: {
        email: `contactar con soporte via correo - ${email}`,
        reset: 'Reiniciar la aplicación',
      },
    },
  },
  loader: {
    fail: 'Hmmmmm, algo fue mal con la carga de este componente... Quizás sea una buena idea intentarlo mas tarde',
  },
  images: {
    failed: 'algo fue mal mientras se cargaba esta imagen :(',
  },
  404: 'Amigo? Que estas buscando?',
};

const dateFormat = 'MMMM DD, YYYY';

const notifications: Notifications = {
  options: {
    anchorOrigin: {
      vertical: 'bottom',
      horizontal: 'left',
    },
    autoHideDuration: 6000,
  },
  maxSnack: isMobile ? 3 : 4,
};

const loader = {
  // no more blinking in your app
  delay: 300, // if your asynchronous process is finished during 300 milliseconds you will not see the loader at all
  minimumLoading: 700, // but if it appears, it will stay for at least 700 milliseconds
};

const defaultMetaTags = {
  image: '/cover.png',
  description: 'Informaciones comerciales al alcance de todos',
};
const giphy404 = 'https://giphy.com/embed/xTiN0L7EW5trfOvEk0';

export {
  loader,
  notifications,
  dateFormat,
  messages,
  repository,
  email,
  title,
  defaultMetaTags,
  giphy404,
  profileConfig,
  apiScope,
  tokenEndpoint,
  userInfo,
  challenge,
  identity,
  mode
};
