import './Sidebar.sass';

import { useState } from 'react';
import { Link } from 'react-router-dom';

import DarkModeIcon from '@mui/icons-material/DarkMode';
import DefaultIcon from '@mui/icons-material/Deblur';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import LightModeIcon from '@mui/icons-material/LightMode';
import { Avatar, Box, CircularProgress, IconButton, Typography } from '@mui/material';
import Collapse from '@mui/material/Collapse';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import SwipeableDrawer from '@mui/material/SwipeableDrawer';

import routes from '@/routes';
import { Routes } from '@/routes/types';
import { useSession } from '@/store/session';
import useSidebar from '@/store/sidebar';
import useTheme from '@/store/theme';
import { Themes } from '@/theme/types';

function Sidebar() {
  const [isSidebarOpen, sidebarActions] = useSidebar();
  const [open, setOpen] = useState<any>({});
  const [theme, themeActions] = useTheme();
  const [, { PI, MENU, ROL }, , , access] = useSession();

  const handleClick = (param: string) => {
    setOpen((prevState: any) => ({ [param]: !prevState[param] }));
  };

  function drawerMenu(routesList: Routes = routes, level = 1, parent = '') {
    return Object.values(routesList)
      .filter(({ title, hide }) => title && !hide)
      .map(({ subPath, path, title, icon: Icon, params = '' }) => {
        const titleForShow = MENU?.[`${parent}${path}`]?.title ?? title;

        const listItem = (
          <ListItem sx={{ p: 0 }} key={path}>
            <ListItemButton
              component={Link}
              to={`${parent}${path}${params}`}
              onClick={sidebarActions.close}
            >
              <ListItemIcon>{Icon ? <Icon /> : <DefaultIcon />}</ListItemIcon>
              <ListItemText>{titleForShow}</ListItemText>
            </ListItemButton>
          </ListItem>
        );

        if (
          subPath === undefined &&
          (access?.[parent]?.includes(path) || access?.hasOwnProperty(path))
        ) {
          return listItem;
        } else if (access?.hasOwnProperty(path)) {
          return (
            <List key={title}>
              <ListItem sx={{ p: 0 }}>
                <ListItemButton onClick={() => handleClick(title)}>
                  <ListItemIcon>{Icon ? <Icon /> : <DefaultIcon />}</ListItemIcon>
                  <ListItemText>{titleForShow}</ListItemText>
                  {open[title] ? <ExpandLess /> : <ExpandMore />}
                </ListItemButton>
              </ListItem>
              <Collapse in={open[title]} timeout="auto" unmountOnExit>
                <List
                  component="div"
                  disablePadding
                  style={{ backdropFilter: `brightness(${1 - 0.1 * level})` }}
                >
                  {drawerMenu(subPath, level++, path)}
                </List>
              </Collapse>
            </List>
          );
        }
      });
  }

  return (
    <SwipeableDrawer
      anchor="left"
      open={isSidebarOpen}
      onClose={sidebarActions.close}
      onOpen={sidebarActions.open}
      disableBackdropTransition={false}
      swipeAreaWidth={15}
      id="sidebar"
    >
      <IconButton
        edge="end"
        size="large"
        component={Link}
        to={'/profile'}
        onClick={sidebarActions.close}
        disabled={!PI?.nombre}
        sx={{ borderRadius: '0', display: 'flex', justifyContent: 'left', width: 250 }}
      >
        <Box>
          {PI?.nombre ? (
            <Avatar
              alt={PI?.nombre}
              sx={{
                width: '3.5rem',
                height: '3.5rem',
                filter: 'drop-shadow(0px 0px 5px #00000052)',
              }}
              src={`https://media.enzona.net/images/user/avatar/${PI?.username}.png`}
            />
          ) : (
            <CircularProgress color="inherit" />
          )}
        </Box>
        <Box m={'auto'}>
          <Typography variant={'body1'} sx={{ fontSize: '1rem', lineHeight: '20px' }}>
            <b>{PI?.username}</b>
            <br />
          </Typography>
          <Typography
            variant={'body2'}
            sx={{ fontSize: '0.8rem', lineHeight: '20px', textTransform: 'uppercase' }}
          >
            {ROL ?? 'Rol no asignado'}
          </Typography>
        </Box>
      </IconButton>
      <Box flex={1}>
        <List sx={{ width: 250 }}>{MENU && drawerMenu()}</List>
      </Box>
      <Box
        sx={{
          width: '100%',
          position: 'sticky',
          bottom: 0,
          textAlign: 'center',
          padding: '10px',
          backdropFilter: 'blur(10px)',
          background: 'none !important',
        }}
      >
        <Box sx={{ cursor: 'pointer' }} onClick={() => themeActions.toggle()}>
          {theme === Themes.DARK ? (
            <LightModeIcon sx={{ margin: ' -3px 0px 0px 5px' }} />
          ) : (
            <DarkModeIcon sx={{ margin: ' -3px 0px 0px 5px' }} />
          )}
        </Box>
      </Box>
    </SwipeableDrawer>
  );
}

export default Sidebar;
