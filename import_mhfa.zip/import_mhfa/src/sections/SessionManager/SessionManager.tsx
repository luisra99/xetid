import './SessionManager.css';
import { createSession, restoreSession } from './actions/management';
import { isValidSession } from './actions/session';
import { useEffect } from 'react';
import { Backdrop, Box } from '@mui/material';
import { getCookie } from '@/helpers/cookies';
import { useBackdrop } from '@/store/backdrop';
import { useSession } from '@/store/session';
import useNotifications from '@/store/notifications';
import { showNotification } from '@/utils/notification/notification';

function SessionManager() {
  const [, notificationsActions] = useNotifications()
  const [backdropState, backdropActions] = useBackdrop();
  const [, , sessionActions] = useSession();
  const client_id = import.meta.env.VITE_ENZONA_CLIENT_ID;
  let timerID: string | number | NodeJS.Timeout | undefined;

  const sessionNotifier = (title: string, subTitle: string, content: string, type: 'success' | 'warning' | 'error') => {
    showNotification(notificationsActions, {
      title,
      subTitle,
      content,
      type,
    });
  }

  const check_session = () => {
    const win = window?.parent?.frames?.['opIFrame' as never] as unknown as HTMLIFrameElement;
    win?.contentWindow?.postMessage(`${client_id} ${getCookie('SESSION_STATE')}`, '*');
  };

  const setTimer = () => {
    check_session();
    timerID = setInterval(check_session, 5 * 1000);
  };

  async function receiveMessage(e: any) {
    const { data, origin } = e;
    if (origin !== 'https://identity.enzona.net' || !isValidSession()) {
      return;
    }

    if (data === 'changed') {
      //   await LogIn().then(() => {
      //     clearInterval(timerID);
      //   })
    }
  }

  useEffect(() => {
    setTimer();
    if (isValidSession()) {
      backdropActions.activate();
      restoreSession(sessionActions).then(()=> backdropActions.deactivate());
    }
    // window.addEventListener('unload', dispatchLogout)
    window.addEventListener('message', receiveMessage, false);
    const code = new URL(window.location.href).searchParams.get('code');
    const session_state = new URL(window.location.href).searchParams.get('session_state');
    if (code && session_state) {
      createSession(sessionActions, code, session_state, backdropActions).then((response) => {
        if (response) {
          sessionNotifier("Inicio de sesión fallido", "Faltan datos para completar el perfil", response.join(', '), 'error')
          console.log(response)
        }
        backdropActions.deactivate()
      });
    }
  }, []);

  return (
    <>
      <Backdrop open={backdropState} sx={{ zIndex: '1200' }}>
        <Box display={'flex'} width={'100%'} height={'100%'} className="backdrop-box">
          <span style={{ margin: 'auto' }} className={'custom-loader'} />
        </Box>
      </Backdrop>
      {/* <iframe
        id="opIFrame"
        src={`https://identity.enzona.net/oidc/checksession?client_id=${client_id}&redirect_uri=${import.meta.env.VITE_SERVER_URL}${import.meta.env.VITE_APP_BASE_URL}`}
        style={{ display: 'none' }}
      /> */}
    </>
  );
}

export default SessionManager;
