import { profileConfig } from "@/config"
import { resetAuthenticatedSession } from "../actions/session"

export default function validateProfile(profile: object) {
    const checkSum = profileConfig.length
    let validParams: string[] = []
    let invalidParams: string[] = []

    profileConfig.forEach(({ key, label, check }) => {
        if (key in profile) {
            if (check && profile[key as never] === check) {
                invalidParams.push(`${label} - ${check}`)
            }
            else {
                validParams.push(label)
            }
        }
        else {
            invalidParams.push(label)
        }
    })

    if (checkSum === validParams.length) {
        console.log(validParams)
        return false
    } else {
        console.log(invalidParams)
        resetAuthenticatedSession()
        return invalidParams
    }
}