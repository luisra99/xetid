import validateProfile from "./validateProfile";
import { defaultMenu,defaultAccessProfile } from "@/config/defaultFeatures";

export function CreateAccessProfile(perfil: any) {
  const profileValidation = validateProfile(perfil);
  if (profileValidation) {
    return profileValidation;
  }
  
  const { ROL, PERMISOS } = perfil.MENU??{};
  const menuItems:any = { ...defaultMenu };
  const accessProfile:any = { ...defaultAccessProfile };
  
  if (PERMISOS?.length) {
    PERMISOS.forEach(({ children, url, titulo, img }:any) => {
      if (children.length) {
        const { permissions, menuItems: extractedMenuItems } = extractPermissions(children, url);
        menuItems[url] = { title: titulo, icon: img };
        Object.assign(menuItems, extractedMenuItems);
        accessProfile[url] = permissions;
      } else {
        menuItems[url] = { title: titulo, icon: img };
        accessProfile[url] = false;
      }
    });
  }
  
  return { MENU: menuItems, accessProfile, ROL, ...perfil };
}
function extractPermissions(
  permissionsArray: any,
  father: string,
): { permissions: string[]; menuItems: object } {
  const { permissions, menuItems } = permissionsArray.reduce(
    ({ permissions, menuItems }: any, { url, titulo: title, img: icon }: any) => {
      permissions.push(url);
      menuItems[`${father}${url}`] = { title, icon };
      return { permissions, menuItems };
    },
    { permissions: [], menuItems: {} },
  );

  return { permissions, menuItems };
}