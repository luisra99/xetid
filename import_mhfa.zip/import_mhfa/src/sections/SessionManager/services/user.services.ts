import { getCookie, setCookie } from '../../../helpers/cookies';
import { CreateAccessProfile } from '../helpers/accessProfile';
import axios from 'axios';

import { apiScope, userInfo, mode } from '@/config';
import { profile } from '@/utils/seededData';

export async function GetProfileConfiguration() {
  try {
    const { data } = mode
      ? { data: profile }
      : await axios.get(`${import.meta.env.VITE_SERVER_URL}${apiScope}${userInfo}`,
      );
    const accessProfile = CreateAccessProfile(data);
    !Array.isArray(accessProfile) && setCookie('PROFILE', accessProfile);
    return accessProfile;
  } catch (error) {
    console.error('Error en la controladora', error);
    return [
      'El servicio ha fallado, asegúrese de estar conectado, pruebe reintentar y si el problema persiste contacte con soporte técnico.',
    ];
  }
}

export function ReclaimRegistration(setState: (value: any) => void, ci: string) {
  setState(false);
  setTimeout(() => setState(true), 5000);
}
