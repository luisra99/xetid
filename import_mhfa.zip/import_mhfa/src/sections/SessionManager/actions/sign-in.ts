import { apiScope, tokenEndpoint, challenge, identity } from '@/config';
import { initAuthenticatedSession, resetAuthenticatedSession } from './session';
import axios from 'axios';
import { setCookie, getCookie } from '@/helpers/cookies';
import { isToken } from '@/utils/seededData';

export type Challenge = {
  verifier: string;
  challenge: string;
};

export const sendAuthorizationRequest = ({
  challenge,
  verifier,
}: {
  challenge: string;
  verifier: string;
}) => {
  resetAuthenticatedSession();
  setCookie('VERIFIER', verifier);
  const authorizeRequest = `${identity}oauth2/authorize?response_type=code&scope=openid&redirect_uri=${import.meta.env.VITE_SERVER_URL}${import.meta.env.VITE_APP_BASE_URL}inicio&client_id=${import.meta.env.VITE_ENZONA_CLIENT_ID
    }&code_challenge=${challenge}&code_challenge_method=S256`;
  window.location.href = authorizeRequest;
};

export const requestChallenge = async (): Promise<any> => {
  try {
    const { data } = await axios.get(`${import.meta.env.VITE_SERVER_URL}${apiScope}${challenge}`);
    return JSON.parse(data);
  } catch (error) {
    console.error('Error en la controladora', error);
    return { challenge: false };
  }
};

export const sendTokenRequest = async (code: string, session_state: string):Promise<any> => {
  let _isToken: any = {};
  
  if (code === 'dev') {
    _isToken = isToken;
  } else {
    await axios
      .post(
        `${import.meta.env.VITE_SERVER_URL}${apiScope}${tokenEndpoint}`,
        {
          code,
          grant_type: 'authorization_code',
          redirect_uri: `${import.meta.env.VITE_SERVER_URL}${import.meta.env.VITE_APP_BASE_URL}inicio`,
          verifier: getCookie('VERIFIER'),
        },
        await getTokenRequestHeaders(),
      )
      .then(async (response:any) => {
        if (response.status !== 200) {
          return Promise.reject(
            new Error('Invalid status code received in the token response: ' + response.status),
          );
        }
        _isToken = JSON.parse(response.data);
        console.log("Parsed token", _isToken)
        console.log("Parsed token", _isToken.access_token)
        if (_isToken.access_token) {
          initAuthenticatedSession(_isToken, session_state);
        }
        return _isToken;
      })
      .catch((error:any) => {
        console.log(error)
        return _isToken
      });
  }
};

const getTokenRequestHeaders = async () => {
  return {
    headers: {
      Accept: 'application/json',
      'Access-Control-Allow-Origin': `${import.meta.env.VITE_CLIENT_URL}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
  };
};
