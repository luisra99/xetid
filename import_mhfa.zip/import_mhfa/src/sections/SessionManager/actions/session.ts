import { getCookie, removeCookie, setCookie } from '../../../helpers/cookies';

interface Session {
  REFRESH_TOKEN: string;
  ID_TOKEN: string;
  EXPIRES_IN: string;
  PROFILE: any;
  NOTIFICATIONS: any;
  SESSION_STATE: any;
}

export const initAuthenticatedSession = (
  { refresh_token, scope, id_token, token_type, expires_in }: any,
  session_state: string,
) => {
  setCookie('REFRESH_TOKEN', refresh_token);
  setCookie('ID_TOKEN', id_token);
  setCookie('EXPIRES_IN', expires_in);
  setCookie('SESSION_STATE', session_state);
};

export const getSessionParameter = (key: any) => {
  return getCookie(key);
};

export const resetAuthenticatedSession = async () => {
  const token = getCookie('ID_TOKEN');
  removeCookie('REFRESH_TOKEN');
  removeCookie('ID_TOKEN');
  removeCookie('EXPIRES_IN');
  removeCookie('PROFILE');
  removeCookie('VERIFIER');
  removeCookie('SESSION_STATE');
  removeCookie('NOTIFICATIONS');
  return token;
};

export const isValidSession = () => {
  const token = getCookie('ID_TOKEN');
  return !!token;
};

export const getAllSessionParameters = async () => {
  const session: Session = {
    REFRESH_TOKEN: getCookie('REFRESH_TOKEN'),
    ID_TOKEN: getCookie('ID_TOKEN'),
    EXPIRES_IN: getCookie('EXPIRES_IN'),
    PROFILE: getCookie('PROFILE'),
    SESSION_STATE: getCookie('SESSION_STATE'),
    NOTIFICATIONS: getCookie('NOTIFICATIONS'),
  };
  return session;
};

export const decodeIdToken = (token: string) => {
  const isToken = token.split('.')[1];
  return isToken ? JSON.parse(atob(isToken)) : '';
};
