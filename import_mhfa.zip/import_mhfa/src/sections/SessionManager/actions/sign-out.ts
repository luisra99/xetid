import { resetAuthenticatedSession } from './session';
import { identity } from '@/config';
export const dispatchLogout = () => {
  resetAuthenticatedSession().then(
    (token) =>
      (window.location.href = `${identity}oidc/logout?id_token_hint=${token}&post_logout_redirect_uri=${import.meta.env.VITE_SERVER_URL}${import.meta.env.VITE_APP_BASE_URL}`),
  );
};
export const getLogoutUrl = (): Promise<string> => {
  const logout = resetAuthenticatedSession().then((token) => {
    return `${identity}oidc/logout?id_token_hint=${token}&post_logout_redirect_uri=${import.meta.env.VITE_SERVER_URL}${import.meta.env.VITE_APP_BASE_URL}`;
  });
  return logout;
};
