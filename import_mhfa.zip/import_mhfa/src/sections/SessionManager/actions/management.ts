import { decodeIdToken, getAllSessionParameters } from './session';
import { requestChallenge, sendAuthorizationRequest, sendTokenRequest } from './sign-in';

import { mode } from '@/config';
import { GetProfileConfiguration } from '@/sections/SessionManager/services/user.services';
import { Actions } from '@/store/session/types';

export async function restoreSession(sessionActions: Actions) {
  const sessionParams = await getAllSessionParameters();
  const { ID_TOKEN } = sessionParams;
  const profile = ID_TOKEN ? await GetProfileConfiguration() : false;
  if (Array.isArray(profile)) {
    return profile;
  } else {
    sessionActions.create({
      tokenResponse: sessionParams,
      idToken: decodeIdToken(ID_TOKEN),
      isLoggedIn: true,
      profile,
    });
    return false;
  }
}
export async function createSession(
  sessionActions: Actions,
  code: string,
  session_state: string,
  backdropActions: any,
): Promise<any> {
  backdropActions.activate();
  history.replaceState({}, document.title, window.location.hostname);
  const token = await sendTokenRequest(code, session_state);
  console.log("Managment token",token);
  console.log("Managment atoken",token?.access_token??'vacio');
  const profile: any = await GetProfileConfiguration();
  if (Array.isArray(profile)) {
    backdropActions.deactivate();
    return profile;
  }

  sessionActions.create({
    tokenResponse: token?.access_token,
    idToken: token?.id_token,
    isLoggedIn: true,
    profile,
    session_state,
  });

  return false;
}

export async function LogIn(): Promise<boolean> {
  if (mode) {
    window.location.href = `${window.location}?code=dev&session_state=dev`;
    return true;
  }
  await requestChallenge().then((challenge) => {
    if (challenge.challenge) {
      sendAuthorizationRequest(challenge);
    } else {
      return false;
    }
  });

  return true;
}
