import { useOnlineStatus } from '@/hooks/useOnlineStatus';
import Alert from '@mui/material/Alert';
import Snackbar from '@mui/material/Snackbar';
import './OfflineIndicator.sass'

export function OfflineIndicator() {
  const online = useOnlineStatus();

  return (
    <Snackbar open={!online} sx={{marginBottom:'20px'}} anchorOrigin={{horizontal:'center',vertical:'bottom'}}>
    <Alert  severity="error" sx={{ width: '100%',backgroundColor:'#d32f2f',color:'whitesmoke',fontWeight:'700' }} >
      Trabajando sin conexión
    </Alert>
  </Snackbar>
  );
}
