import AppBar from '@mui/material/AppBar';
import Button from '@mui/material/Button';
import { styled } from '@mui/system';

const HotKeysButton = styled(Button)(({ theme }) => ({
  height: 'fit-content',
  alignSelf: 'center',
  marginRight: theme.spacing(1),
  borderColor: theme.palette.text.disabled,
  '&:hover': {
    borderColor: theme.palette.text.disabled,
  },
  color: theme.palette.text.disabled,
}));
const StyledAppBar = styled(AppBar)(({ theme }) => ({
  backgroundColor: '#29539b',
  backgroundImage: 'radial-gradient(circle at 75% 23%, rgba(226, 226, 226,0.05) 0%, rgba(226, 226, 226,0.05) 50%,rgba(11, 11, 11,0.05) 50%, rgba(11, 11, 11,0.05) 100%),radial-gradient(circle at 75% 51%, rgba(168, 168, 168,0.05) 0%, rgba(168, 168, 168,0.05) 50%,rgba(75, 75, 75,0.05) 50%, rgba(75, 75, 75,0.05) 100%),radial-gradient(circle at 38% 11%, rgba(31, 31, 31,0.05) 0%, rgba(31, 31, 31,0.05) 50%,rgba(254, 254, 254,0.05) 50%, rgba(254, 254, 254,0.05) 100%),linear-gradient(179deg, rgb(46 106 159),rgb(31 91 155))',
}));

export { HotKeysButton, StyledAppBar };
