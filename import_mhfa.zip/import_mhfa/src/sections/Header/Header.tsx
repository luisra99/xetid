import './Header.sass';
import HeaderToolbar from './components/HeaderToolbar';
import { StyledAppBar } from './styled';

import MenuIcon from '@mui/icons-material/Menu';
import IconButton from '@mui/material/IconButton';
import Toolbar from '@mui/material/Toolbar';

import { FlexBox } from '@/shared/components/styled';
import { useSession } from '@/store/session';
import useSidebar from '@/store/sidebar';

function Header() {
  const [, sidebarActions] = useSidebar();
  const [sessionState, ,] = useSession();

  return (
    <StyledAppBar className={'app-header'} color="default" elevation={1} position="fixed">
      <Toolbar className="toolBar" sx={{ justifyContent: 'space-between', minHeight: '64px' }}>
        <FlexBox sx={{ alignItems: 'center' }}>
          {sessionState && (
            <IconButton
              onClick={sidebarActions.toggle}
              size="large"
              edge="start"
              color="info"
              aria-label="menu"
              sx={{
                mr: 1,
                color: '#fff',
              }}
              className="menu-icon"
            >
              <MenuIcon />
            </IconButton>
          )}
        </FlexBox>

        <FlexBox>
          <HeaderToolbar />
        </FlexBox>
      </Toolbar>
    </StyledAppBar>
  );
}

export default Header;
