import { useState } from 'react';

import LoginIcon from '@mui/icons-material/Login';
import LogOut from '@mui/icons-material/Logout';
import {
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from '@mui/material';
import IconButton from '@mui/material/IconButton';
import Tooltip from '@mui/material/Tooltip';

import { LogIn } from '@/sections/SessionManager/actions/management';
import { dispatchLogout } from '@/sections/SessionManager/actions/sign-out';
import { useSession } from '@/store/session';

function HeaderToolbar() {
  const [gettingChallenge, setGettingChallenge] = useState(false);
  const [open, setOpen] = useState(false);
  const [sessionState, , ,] = useSession();

  return (
    <>
      <Dialog open={open}>
        <DialogTitle>Por favor confirme</DialogTitle>
        <DialogContent>Esta seguro que desea cerrar sesión?</DialogContent>
        <DialogActions>
          <Button
            variant="outlined"
            onClick={() => {
              setOpen(false);
            }}
          >
            Cancelar
          </Button>
          <Button
            variant="contained"
            onClick={async () => {
              dispatchLogout();
            }}
            color="primary"
          >
            Cerrar Sesión
          </Button>
        </DialogActions>
      </Dialog>
      {sessionState ? (
        <Tooltip className="header-button" title="Cerrar Sesión" arrow>
          <IconButton
            edge="end"
            size="large"
            onClick={() => {
              setOpen(true);
            }}
          >
            <LogOut />
          </IconButton>
        </Tooltip>
      ) : (
        <>
          <Tooltip className="header-button" title="Iniciar sesión" arrow>
            <Button
              size="large"
              disabled={gettingChallenge}
              onClick={async () => {
                setGettingChallenge(true);
                LogIn().then(() => {
                  setGettingChallenge(false);
                });
              }}
            >
              {!gettingChallenge ? <LoginIcon /> : <CircularProgress color="inherit" />}
            </Button>
          </Tooltip>
        </>
      )}
    </>
  );
}

export default HeaderToolbar;
