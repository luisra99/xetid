import { Pages, Routes } from './types';
import { ShowChart,  TableChart } from '@mui/icons-material';
import HomeIcon from '@mui/icons-material/Home';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import LiveHelpIcon from '@mui/icons-material/LiveHelp';
import InfoIcon from '@mui/icons-material/Info';
import asyncComponentLoader from '@/utils/loader';
import myRoutes from './MyRoutes';
const routes: Routes = {
  ...myRoutes,
  [Pages.LandingPage]: {
    component: asyncComponentLoader(() => import('@/pages/LandingPage')),
    path: '/',
    title: '',
  },
  [Pages.Welcome]: {
    component: asyncComponentLoader(() => import('@/pages/Welcome')),
    path: '/inicio',
    title: 'Inicio',
    icon: HomeIcon,
  },
  [Pages.Perfil]: {
    component: asyncComponentLoader(() => import('@/pages/Profile')),
    path: '/profile',
    title: '',
  },
  [Pages.FAQS]: {
    component: asyncComponentLoader(() => import('@/pages/PreguntasFrecuentes/PreguntasFrecuentes')),
    path: '/preguntas',
    title: 'Preguntas Frecuentes',
    icon: LiveHelpIcon,
  },
  [Pages.TerminosCondiciones]: {
    component: asyncComponentLoader(() => import('@/pages/TerminosCondiciones/TerminosCondiciones')),
    path: '/terminos',
    title: '',
  },
  [Pages.PoliticaPrivacidad]: {
    component: asyncComponentLoader(() => import('@/pages/PoliticaPrivacidad/PoliticaPrivacidad')),
    path: '/politicas',
    title: '',
  },
  [Pages.Acerca]: {
    component: asyncComponentLoader(() => import('@/pages/Acerca/Acerca')),
    path: '/acerca',
    title: 'Acerca de...',
    icon: InfoIcon
  },
  [Pages.NoAutorizado]: {
    path: '/unauthorized',
    component: asyncComponentLoader(() => import('@/pages/Unauthorized')),
    title: '',
  },

  [Pages.NotFound]: {
    component: asyncComponentLoader(() => import('@/pages/NotFound/NotFound')),
    path: '*',
    title: '',
  },
};

export default routes;
