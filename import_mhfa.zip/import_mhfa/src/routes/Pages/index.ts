import Pages from './Pages';

export default Pages;
