import routes from '..';
import OutSideRoute from '../ProtectedRoutes/OutSideRoute';
import PrivateRoute from '../ProtectedRoutes/ProtectedRoute';
import { getPageHeight } from './utils';

import { Fragment } from 'react';
import { Route, Routes } from 'react-router-dom';

import Box from '@mui/material/Box';

import LandingPage from '@/pages/LandingPage';

function Pages() {
  return (
    <Box sx={{ height: (theme) => getPageHeight(theme), marginTop: '64px' }}>
      <Routes>
        <Route path="/" element={<OutSideRoute component={LandingPage} />} />

        {Object.values(routes).map(({ path, component: Component, subPath }) => {
          if (Component) {
            return (
              <Route
                key={path}
                path={path}
                element={<PrivateRoute component={Component} path={path} childPath={false} />}
              />
            );
          }

          return (
            subPath &&
            Object.values(subPath).map(({ path: childPath, component: ChildComponent }) => {
              if (ChildComponent) {
                const completePath = path + childPath;
                return (
                  <Fragment key={completePath}>
                    <Route
                      key={completePath}
                      path={completePath}
                      element={
                        <PrivateRoute
                          component={ChildComponent}
                          path={path}
                          childPath={childPath}
                        />
                      }
                    />
                  </Fragment>
                );
              }
              return null;
            })
          );
        })}
      </Routes>
    </Box>
  );
}

export default Pages;
