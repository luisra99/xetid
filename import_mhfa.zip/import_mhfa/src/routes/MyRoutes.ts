import { Pages, Routes } from './types';
import asyncComponentLoader from '@/utils/loader';

const myRoutes: Routes = {
  [Pages.Importar]: {
    component: asyncComponentLoader(() => import('@/pages/Importar')),
    path: '/import',
    title: 'Importar',
  },
};

export default myRoutes;
