import { Navigate } from 'react-router-dom';

import { useSession } from '@/store/session';

const PrivateRoute = ({
  component: Component,
  path,
  childPath = '',
}: {
  component: React.FC;
  path: string;
  childPath: string | boolean;
}) => {
  const [sessionState, , , , access] = useSession();
  const authorization = () => {
    if (path in (access ?? {})) {
      if (childPath) {
        if (access[path]?.includes(childPath as string)) {
          return true;
        } else {
          return false;
        }
      }
      return true;
    }
    return false;
  };

  const route = authorization() || path === '/inicio' || path === '/unauthorized';
  if (sessionState) {
    return route ? <Component /> : <Navigate to="/inicio" />;
  }
  return <Navigate to="/" />;
};
export default PrivateRoute;
