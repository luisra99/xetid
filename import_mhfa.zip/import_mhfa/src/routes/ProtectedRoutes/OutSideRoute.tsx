import { Navigate } from 'react-router-dom';

import { useSession } from '@/store/session';

const OutSideRoute = ({
  component: Component,

}: {
  component: React.FC;
}) => {
  const [sessionState, ,] = useSession();
  return !sessionState ? <Component /> : <Navigate to="/inicio" />;
};
export default OutSideRoute;
