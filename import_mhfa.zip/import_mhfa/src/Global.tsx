import CssBaseline from '@mui/material/CssBaseline';

import Notifications from '@/sections/Notifications';
import SW from '@/sections/SW';

export default function Global() {
  return (
    <>
      <CssBaseline />
      <Notifications />
      <SW />
    </>
  );
}
