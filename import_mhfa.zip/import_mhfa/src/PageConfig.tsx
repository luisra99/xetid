import { StrictMode } from 'react';
import { HelmetProvider } from 'react-helmet-async';
import { RecoilRoot } from 'recoil';

import ThemeProvider from '@/theme/Provider';

function PageConfig({ children }: { children: any }) {
  return (
    <StrictMode>
      <RecoilRoot>
        <HelmetProvider>
          <ThemeProvider>{children}</ThemeProvider>
        </HelmetProvider>
      </RecoilRoot>
    </StrictMode>
  );
}

export default PageConfig;
