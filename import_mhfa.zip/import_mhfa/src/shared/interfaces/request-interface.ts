import { AxiosHeaders } from 'axios';

export interface RequestData {
  method: string;
  params: object;
  url: string;
  data: object;
}
export interface RequestOptions {
  method: string;
  url: string;
  data: RequestData;
}

type AxiosHeaderValue = AxiosHeaders | string | string[] | number | boolean | null;
export interface RawAxiosHeaders {
  [key: string]: AxiosHeaderValue;
}
