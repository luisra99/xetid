import { ReactNode } from 'react';

export type AccordionData = {
  title: string;
  content: ReactNode;
};
