import Meta from './Meta';

export default Meta;
