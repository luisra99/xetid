import PageConfig from './PageConfig';

import { ComponentType } from 'react';
import { createRoot } from 'react-dom/client';

const container = document.getElementById('root') as HTMLElement;
const root = createRoot(container);

function render(App: ComponentType) {
  root.render(
    <PageConfig>
      <App />
    </PageConfig>,
  );
}

export default render;
