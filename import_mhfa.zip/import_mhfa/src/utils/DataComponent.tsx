import Loading from "@/shared/components/Loading"
import { ReactElement } from "react"
/**
 * Contenedor de componentes que muestren datos, se encierra en su cuerpo el componente desea usar y el hook que contendrá los datos se pasa en el parámetro 'data'.
 * @param  {[type]} data Recibe el state que almacena los datos que utiliza el componente hijo
 * @param  {[type]} errorValue Por defecto se compara el state con -1 como respuesta a si hubo error, con este parámetro se define el valor de una respuesta errónea
 * @param  {[type]} children El componente que se va a utilizar con los datos ej: \<DataComponent>\{(datos)=>\<componente/>}\</DataComponent>
 * @param  {[type]} fallbackComponent Componente personalizado para cuando este cargando los datos
 * @param  {[type]} fallbackEmpty Componente personalizado para cuando los datos estén vacíos
 * @param  {[type]} fallbackError Componente personalizado para cuando halla error cargando los datos
 * @return {[type]} Devuelve uno de los componentes dependiendo del estado de 'data'
 */
const  DataComponent=({data,children,
    errorValue=-1,
    fallbackComponent=<Loading/>,
    fallbackEmpty=<h5 style={{textAlign:'center'}}>No existen datos registrados.</h5>,
    fallbackError=<h5 style={{textAlign:'center'}}>Lo sentimos, ha ocurrido un error obteniendo la información deseada.</h5>}:
    {data:any,errorValue?:any,children:DataComponentChildren,fallbackComponent?:ReactElement,fallbackEmpty?:ReactElement,fallbackError?:ReactElement}):any =>{
    console.log(data?.length)
    if(data){
        if(data===errorValue)
        return fallbackError
        if(data.length===0)
        return fallbackEmpty
        else
        return children(data)
    }else{
        return fallbackComponent
    }
}
/** 
 * Función que recibe los datos y los utiliza en el componente definido
 * @param {any} data - Parámetro que tomara el valor de data para usarse en el componente que defina.
 * @returns {ReactElement} Devuelve el resultado de utilizar los valores de data en el componente definido
 */
interface DataComponentChildren{
    (data:any):ReactElement
}

export default DataComponent
