export const dateToNumbers=(date?:Date)=>date?`${date.getDate()+1}-${date.getMonth()+1}-${date.getFullYear()}`:'Fecha no establecida'
export const dateToStringFull=(date?:Date)=>date?`${week[date.getDay() as never]}, ${date.getDate()+1} de ${month[date.getMonth()+1 as never]} del ${date.getFullYear()}`:'Fecha no establecida'
export const dateToString=(date?:Date)=>date?`${date.getDate()+1} de ${month[date.getMonth()+1 as never]} del ${date.getFullYear()}`:'Fecha no establecida'

const week={
    0:'lunes',
    1:'martes',
    2:'miércoles',
    3:'jueves',
    4:'viernes',
    5:'sábado',
    6:'domingo'
}
const month={
    1:'enero',
    2:'febrero',
    3:'marzo',
    4:'abril',
    5:'mayo',
    6:'junio',
    7:'julio',
    8:'agosto',
    9:'septiembre',
    10:'octubre',
    11:'noviembre',
    12:'diciembre'
}