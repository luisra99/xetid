import { useEffect, useState } from 'react';

import { Backdrop, Box, Button, CircularProgress, Typography } from '@mui/material';

import { resetAuthenticatedSession } from '@/sections/SessionManager/actions/session';

function BackDrop() {
  const [message, setMessage] = useState(false);
  useEffect(() => {
    setTimeout(() => setMessage(true), 5000);
  }, []);

  return (
    <Backdrop open={true}>
      <CircularProgress color="inherit"></CircularProgress>
      {message && (
        <Box
          p={1}
          m={1}
          sx={{
            bottom: '0',
            position: 'absolute',
            display: 'flex',
            background: 'rgba(0, 0, 0, 0.7)',
          }}
          justifyContent={'center'}
          width={'100%'}
        >
          <Typography p={1}>Este proceso esta demorando más de lo esperado</Typography>
          <Button
            onClick={() => {
              setMessage(false);
              resetAuthenticatedSession();
            }}
            variant={'contained'}
          >
            Reiniciar
          </Button>
        </Box>
      )}
    </Backdrop>
  );
}

export default BackDrop;
