import { dispatchLogout } from "@/sections/SessionManager/actions/sign-out";

function resetApp() {
  dispatchLogout()
  return window.location.reload();
}

export default resetApp;
