type Actions = {
  create: (params?: any) => void;
  close: () => void;
};

type Session = {
  tokenResponse?: string;
  idToken?: string;
  isLoggedIn: boolean;
  profile: Profile;
  notifications?: any;
  session_state?:any;
};
export type AccessProfile = Record<string, string[]>;

type Profile = {
  accessProfile: AccessProfile;
} & Record<any, any>;

export type { Actions, Session };
