import { isValidSession } from '../../sections/SessionManager/actions/session';
import type { Actions, Session } from './types';
import { AccessProfile } from './types';

import { useEffect } from 'react';
import { atom, useRecoilState } from 'recoil';

import { restoreSession } from '@/sections/SessionManager/actions/management';

const defaultSession = {
  isLoggedIn: isValidSession(),
  profile: { accessProfile: {} },
};

const sessionState = atom<Session>({
  key: 'session-state',
  default: defaultSession,
});

export function useSession(): [boolean, any, Actions, any, AccessProfile] {
  const [session, setSession] = useRecoilState(sessionState);
  useEffect(() => {
    if (isValidSession()) {
      restoreSession({ close, create });
    }
  }, []);

  function close() {
    const session = {
      isLoggedIn: false,
      profile: { accessProfile: {} },
    };
    setSession(session);
  }

  function create(params: any) {
    params.isLoggedIn = true;
    setSession(params);
  }
  const { isLoggedIn, profile, notifications } = session;
  const { accessProfile } = profile ?? {};
  return [isLoggedIn, profile, { close, create }, notifications, accessProfile];
}
