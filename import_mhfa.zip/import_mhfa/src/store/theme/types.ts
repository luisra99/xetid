type Actions = {
  toggle: () => void;
};

export type { Actions };
