type Actions = {
  activate: () => void;
  deactivate: () => void;
};

export type { Actions };
