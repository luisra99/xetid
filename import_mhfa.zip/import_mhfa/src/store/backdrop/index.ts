
import { atom, useRecoilState } from 'recoil';
import { Actions } from './types';

const sessionState = atom<boolean>({
  key: 'backdrop-state',
  default: false,
});

export function useBackdrop(): [boolean, Actions] {
  const [status, setStatus] = useRecoilState(sessionState);

  function activate() {
    setStatus(true);
  }

  function deactivate() {
    setStatus(false);
  }

  return [status,{activate,deactivate}];
}
