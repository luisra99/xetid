import Global from './Global';
import Header from './sections/Header';
import { OfflineIndicator } from './sections/OfflineIndicator/OfflineIndicator';
import SessionManager from './sections/SessionManager';
import Sidebar from './sections/Sidebar';

import { BrowserRouter } from 'react-router-dom';

import { withErrorHandler } from '@/error-handling';
import AppErrorBoundaryFallback from '@/error-handling/fallbacks/App';
import Pages from '@/routes/Pages';

function App() {
  return (
    <>
      <Global />
      <BrowserRouter basename={`${import.meta.env.VITE_APP_BASE_URL}`}>
        <Header />
        <Sidebar />
        <SessionManager />
        <Pages />
        <OfflineIndicator />
      </BrowserRouter>
    </>
  );
}

export default withErrorHandler(App, AppErrorBoundaryFallback);
