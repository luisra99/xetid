import { Fragment, useState } from 'react';
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Collapse from '@mui/material/Collapse';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import { Typography } from '@mui/material';

export default function Preguntas(props: any) {
    const { rows } = props
    const [open, setOpen] = useState<any>({});

    const handleClick = (param: string) => {
        setOpen((prevState: any) => ({ [param]: !prevState[param] }));
    };
    const rows1 = [
        {
            pregunta: '¿Cómo inicio sesión en mi cuenta?',
            respuesta: <>
                La plataforma en la que estás intentando iniciar sesión, utiliza ....</>
        }
    ]

    return (
        <List
            sx={{ width: '100%', maxWidth: '100%', textAlign: 'center' }}
            component="nav"
        >
            <ListItemButton >
                <Typography variant="subtitle1" component="div" sx={{ fontWeight: '600', fontSize: '18px' }}>
                    Preguntas Frecuentes
                </Typography>
            </ListItemButton>
            {rows.map(({ pregunta, respuesta }: any) => (
                <Fragment key={pregunta}>
                    <ListItemButton onClick={() => handleClick(pregunta)} sx={{ borderCollapse: 'collapse' }}>
                        <ListItemText
                            primary={<Typography variant="body2" textAlign='left' sx={{ fontWeight: 'bold' }}>
                                {pregunta}
                            </Typography>}
                            sx={{ borderCollapse: 'collapse', textAlign: 'left', marginLeft: '0px' }} />

                        {open[pregunta] ? <ExpandLess /> : <ExpandMore />}
                    </ListItemButton>
                    <Collapse in={open[pregunta]} timeout="auto" unmountOnExit sx={{ borderCollapse: 'collapse' }}>
                        <List component="div" disablePadding sx={{ borderCollapse: 'collapse' }}>
                            <ListItemButton sx={{ pl: 2, borderCollapse: 'collapse' }} >
                                <ListItemText
                                    primary={
                                        <Typography variant="body2" textAlign='justify' >
                                            {respuesta}
                                        </Typography>}
                                    sx={{ textAlign: 'left', marginLeft: '0px', borderCollapse: 'collapse' }} />
                            </ListItemButton>
                        </List>
                    </Collapse>
                </Fragment>
            ))}
        </List>
    );
}