import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import { Grid, TextField, Link } from '@mui/material';
import Button from '@mui/material/Button';
import Preguntas from './ListPreguntas';
import { GetPreguntasFrecuentes } from '@/services/preguntasfrecuentes/preguntasfrecuentes.service';
import { FAQS } from '@/shared/interfaces/common';

export default function PreguntasFrecuentes() {
    const [nombre, setNombre] = useState("")
    const [correo, setCorreo] = useState('')
    const [asunto, setAsunto] = useState("")
    const [descripcion, setDescripcion] = useState("")
    const [error, setError] = useState('');
    const [rows, setRows] = useState<any>([]);
    const [rendering, setRendering] = useState<boolean>(false);

    function PreguntasFrecuentes() {
        GetPreguntasFrecuentes().then(
            (response: any) => {
                setRows(response);
                setRendering(true)
            },
        );
    }
    useEffect(() => {
        PreguntasFrecuentes()
    }, []);

    function isValidEmail(correo: any) {
        return /\S+@\S+\.\S+/.test(correo);
    }
    const handleChange = (event: any) => {
        if (!isValidEmail(event.target.value)) {
            setError('Dirección de correo incorrecta')
        } else {
            setError('');
        }
        setCorreo(event.target.value);
    }
    const EnviarDatos = () => {
        // setDatos(event.target.value)
        const datos = { nombre, correo, asunto, descripcion }
        console.log('datos', datos)
        setNombre("")
        setCorreo("")
        setAsunto("")
        setDescripcion("")
    }
    return (
        <>{rendering && <Paper
            sx={{
                p: 2,
                margin: 'auto',
                borderRadius: '10px',
                maxWidth: '95vw',
                marginTop: '10vh'
            }}
        >
            <Grid container direction="row" rowSpacing={2} marginBottom={2} justifyContent={'center'} >
                <Grid item xs={11} width={'100%'} >
                    <Preguntas rows={rows} />
                </Grid>
                <Grid container xs={11} item justifyContent="center" alignItems="center" width={'100%'}>
                    <Paper sx={{ borderRadius: '20px' }}>
                        <Grid container rowSpacing={6} justifyContent="center" alignItems="center">
                            <Grid item xs={12} sm={12} md={12} >
                                <Typography variant="subtitle1" textAlign='center' component="div" sx={{ fontWeight: '600', fontSize: '18px', marginTop: 3 }}>
                                    ¿Desea preguntar algo más?
                                </Typography></Grid>
                            <Grid item xs={12} sm={12} md={12} >
                                <form >
                                    <Grid container direction="row" justifyContent="center" rowSpacing={2} marginBottom={2} >
                                        <Grid container direction="row" justifyContent="center" rowSpacing={2} marginBottom={2}>
                                            <Grid item xs={12} sm={12} md={12}>
                                                <TextField
                                                    sx={{ padding: 1 }}
                                                    type="text"
                                                    label="Nombre"
                                                    name={nombre}
                                                    value={nombre}
                                                    onChange={(event) => { setNombre(event.target.value) }}
                                                    onKeyPress={(event) => {
                                                        if (!/^[A-Za-z ]+$/g.test(event.key)) {
                                                            event.preventDefault();
                                                        }
                                                    }}
                                                    fullWidth
                                                />
                                            </Grid>
                                            <Grid item xs={12} sm={12} md={12}>
                                                <TextField
                                                    sx={{ padding: 1 }}
                                                    type="email"
                                                    label="Correo"
                                                    fullWidth
                                                    name={correo}
                                                    value={correo}
                                                    onChange={handleChange}
                                                />
                                                <Typography variant="subtitle1" textAlign='center' component="div" sx={{ color: 'red', fontSize: '10px' }}>
                                                    {error}
                                                </Typography>

                                            </Grid>
                                            <Grid item xs={12} sm={12} md={12}>
                                                <TextField
                                                    sx={{ padding: 1 }}
                                                    type="text"
                                                    label="Asunto"
                                                    fullWidth
                                                    name={asunto}
                                                    value={asunto}
                                                    onChange={(event) => { setAsunto(event.target.value) }}
                                                    onKeyPress={(event) => {
                                                        if (!/^[A-Za-z ]+$/g.test(event.key)) {
                                                            event.preventDefault();
                                                        }
                                                    }}
                                                />
                                            </Grid>
                                            <Grid item xs={12} sm={12} md={12}>
                                                <TextField
                                                    sx={{ padding: 1 }}
                                                    type="text"
                                                    label="Su Pregunta"
                                                    name={descripcion}
                                                    value={descripcion}
                                                    onChange={(event) => { setDescripcion(event.target.value) }}
                                                    fullWidth
                                                    multiline
                                                    rows={5}
                                                />
                                            </Grid>
                                        </Grid>
                                        <Grid container direction="column" marginBottom={2} alignContent={'center'} alignItems={'center'}>
                                            <Grid item xs={12} sm={6} md={6} >
                                                <Button
                                                    variant='contained'
                                                    type='button'
                                                    name='aceptar'
                                                    onClick={EnviarDatos}
                                                >
                                                    <strong>Registrar Pregunta</strong>
                                                </Button>
                                            </Grid>
                                        </Grid>
                                        <Grid container direction="column" marginBottom={2} alignContent={'center'} alignItems={'center'}>
                                            <Typography variant="subtitle1" textAlign='center' component="div" sx={{ fontFamily: '"Sofia", sans-serif', fontWeight: 'bold', fontSize: '12px' }}>
                                                Puede contactarnos en:<Link href={`mailto:xetiddigital@xetid.cu`}> xetid@xetid.cu</Link>
                                            </Typography>
                                        </Grid>
                                    </Grid>
                                </form>
                            </Grid >
                        </Grid>
                    </Paper>
                </Grid>
            </Grid>
        </Paper>} </>


    );
}
