import PreguntasFrecuentes from './PreguntasFrecuentes';

export default PreguntasFrecuentes;
