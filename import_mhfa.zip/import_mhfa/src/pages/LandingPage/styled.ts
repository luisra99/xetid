import { styled } from '@mui/system';

const Image = styled('img')({
  width: '10%',
  height: '10%',
  margin: 4,
});

export { Image };
