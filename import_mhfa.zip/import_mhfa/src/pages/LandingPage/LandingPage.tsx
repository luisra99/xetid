import './LandingPage.sass';
import LoadingButton from '@mui/lab/LoadingButton';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Meta from '@/shared/components/Meta';
import { LogIn } from '@/sections/SessionManager/actions/management';
import { useState } from 'react';

function LandingPage() {
  const [gettingChallenge, setGettingChallenge] = useState<boolean>()
  return (
    <>
      <Meta title="Inicio" />
      <Box className="landing-page-box" sx={{ textAlign: 'right', display: { xs: 'content', sm: 'flex' } }} margin={'auto'}>
        <Box sx={{ display: { sm: 'block', md: 'none' }, margin: { sm: 'auto 0 auto -50vw' } }} width={'100vw'}>
          <img src={'/landing-mobile.png'} alt="React PWA Template" style={{ maxWidth: '100vw' }} className='landing-image' />
        </Box>
        <Box sx={{ margin: { xs: 3, sm: 'auto' }, textAlign: 'left', width: { xs: '100vw', sm: '50vw' } }}>
          <Typography p={3} ml={3} pb={0} variant="h3" sx={{ textAlign: 'left', fontSize: { xs: 40, sm: 30, md: 35, lg: 40 } }} fontWeight={800}>
            React PWA Template
          </Typography>
          <Typography px={3} pb={2} mx={3} variant="h4" sx={{ textAlign: 'left', display: { xs: 'none', sm: 'none', md: 'block' }, fontSize: { sm: 25, md: 20, lg: 25 } }}>
            El sistema que le permitirá ...
          </Typography>
          <Typography px={3} pb={2} mx={3} variant="h4" sx={{ textAlign: 'left', display: { sm: 'block', md: 'none' }, fontSize: { xs: 20, sm: 20 } }}>
            Registra, notifica y ...
          </Typography>
          <LoadingButton loading={gettingChallenge} style={{ marginLeft: 48, marginTop: 24 }} variant={'contained'} size='large' onClick={async () => {
            setGettingChallenge(true);
            LogIn().then(() => {
              setGettingChallenge(false);
            })
          }}>INICIAR SESIÓN</LoadingButton>
        </Box>
        <Box sx={{ display: { xs: 'none', sm: 'none', md: 'block' } }} width={'70vw'} >
          <img src={'/landing.svg'} alt="React PWA Template" style={{ maxHeight: '90vh' }} />
        </Box>
      </Box>
    </>
  );
}

export default LandingPage;
