
import { Grid, Paper, styled, Button, Link, Tooltip, IconButton } from '@mui/material';
import Typography from '@mui/material/Typography';
import Meta from '@/shared/components/Meta';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';

const Img = styled('img')({
    margin: 'auto',
    display: 'inline-block',
    maxWidth: '100%',
    maxHeight: '100%',
});

function Acerca() {
    return (
        <>
            <Meta title="Acerca" />
            <Paper
                sx={{
                    p: 2,
                    margin: 'auto',
                    maxWidth: '95vw',
                    flexGrow: 1,
                    borderRadius: '10px',
                    marginTop: '10vh'
                }}
                elevation={6}
            >
                <Grid container spacing={{ xs: '2', md: '2' }} justifyContent="space-evenly" alignItems="center" m={0}  >
                    <Grid item >
                        <Img alt="React PWA Template" height='165' width='165' src="/favicon.svg" />
                    </Grid>
                    <Grid item xs={12} sm={6} md={6} >
                        <Grid item container direction="column" spacing={1}>
                            <Grid item xs>
                                <Typography variant="subtitle1" textAlign='center' component="div" sx={{ fontWeight: 'bold', fontSize: '25px' }}>
                                React PWA Template
                                </Typography>
                            </Grid>
                            <Grid item xs>
                                <Typography variant="subtitle1" textAlign='center' component="div" sx={{ fontWeight: 'bold', fontSize: '15px' }}>
                                    Versión  1.0.0
                                </Typography>
                                <Typography variant="body2" textAlign='justify' sx={{ fontWeight: 'bold', fontSize: '12px' }}>
                                    "React PWA Template" es una plataforma innovadora creada por ...
                                </Typography>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
                <Grid container
                    direction='row'
                    justifyContent="center"
                    alignItems="center"
                    spacing={{ xs: '0', md: '4' }}
                >
                    <Tooltip title='Términos y condiciones'>
                        <Button variant="text" href="/terminos">
                            <Typography variant="subtitle1" sx={{ fontWeight: 'bold', fontSize: '12px', textAlign: 'center' }}>
                                Términos y condiciones de uso
                            </Typography>
                        </Button>
                    </Tooltip>
                    <Tooltip title='Políticas de privacidad'>
                        <Button variant="text" href="/politicas">
                            <Typography variant="subtitle1" sx={{ fontWeight: 'bold', fontSize: '12px', textAlign: 'center' }}>
                                Políticas de privacidad
                            </Typography>
                        </Button>
                    </Tooltip>
                </Grid>
                <Grid container
                    direction='column'
                    justifyContent="center"
                    alignItems="center"
                >
                    <Grid container
                        direction='row'
                        justifyContent="center"
                        alignItems="center"
                    >
                        <Typography gutterBottom variant="subtitle1" component="div" sx={{ fontWeight: 'bold', fontSize: '12px', position: 'initial', textAlign: 'center' }}>
                            Correo :
                        </Typography>
                        <Typography gutterBottom variant="subtitle1" component="div" sx={{ fontWeight: 'bold', fontSize: '12px', position: 'initial', textAlign: 'center' }}>
                            <Link href={`mailto:xetid@xetid.cu`}>  xetid@xetid.cu</Link>
                        </Typography>

                    </Grid>
                    <Grid container
                        direction='row'
                        justifyContent="center"
                        alignItems="center"
                        marginTop={1}
                    >
                        <Typography gutterBottom variant="subtitle1" component="div" sx={{ fontWeight: 'bold', fontSize: '12px', position: 'initial' }}>
                            Síguenos en
                        </Typography>
                        <Tooltip title='WhatsApp' >
                            <IconButton aria-label="fingerprint" color="inherit" href={"http://atencionacliente.chat.WhatSApApp.cu"}>
                                <WhatsAppIcon color='inherit' aria-label="WhatSApApp" sx={{ marginLeft: '3px' }} />
                            </IconButton>
                        </Tooltip>
                    </Grid>
                    <Grid container
                        direction='row'
                        justifyContent="center"
                        alignItems="center"
                        marginTop={1}
                    >
                        <Typography gutterBottom variant="subtitle1" component="div" sx={{ fontWeight: 'bold', fontSize: '12px', textAlign: 'center' }}>
                            © 2023 Xetid. Todos los derechos reservados
                        </Typography>

                    </Grid>
                </Grid>
            </Paper>

        </>
    );
}

export default Acerca;
