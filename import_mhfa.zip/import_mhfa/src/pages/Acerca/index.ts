import Acerca from './Acerca';

export default Acerca;
