
import { Grid } from '@mui/material';
import Typography from '@mui/material/Typography';
import Meta from '@/shared/components/Meta';
import Paper from '@mui/material/Paper';

function TerminosCondiciones() {
    return (
        <>
            <Meta title="Términos y Condiciones" />
            <Paper
                sx={{
                    p: 2,
                    margin: 'auto',
                    borderRadius: '10px',
                    maxWidth: '95vw',
                    marginTop: '10vh'
                }}
            >
                <Grid container p={2}>
                    <Grid item xs={12}>
                        <Typography variant="subtitle1" textAlign='center' component="div" sx={{ fontWeight: 'bold', fontSize: '18px' }}>
                            Término y condiciones de uso
                        </Typography>
                        <Typography variant="subtitle1" textAlign='center' component="div" sx={{ fontSize: '10px', fontWeight: 'bold', marginTop: 2, textAlign: 'center' }}>
                            <>
                                ( El siguiente texto no está vigente, solo se muestra temporalmente  en lo que se  elabora el ducumento oficial.)
                            </>

                        </Typography>
                        <Typography variant="subtitle1" textAlign='justify' component="div" sx={{ fontSize: '15px', marginTop: 3 }}>
                            <>
                                <strong>INFORMACIÓN RELEVANTE</strong> <br />
                                Es requisito necesario para la adquisición de los productos que se ofrecen en este sitio, que lea y acepte los siguientes <strong>Términos y Condiciones </strong> que a continuación se redactan. El uso de nuestros servicios así como la compra de nuestros productos implicará que usted ha leído y aceptado los <strong>Términos y Condiciones de Uso</strong> en el presente documento. Todas los productos  que son ofrecidos por nuestro sitio web pudieran ser creadas, cobradas, enviadas o presentadas por una página web tercera y en tal caso estarían sujetas a sus propios Términos y Condiciones. En algunos casos, para adquirir un producto, será necesario el registro por parte del usuario, con ingreso de datos personales fidedignos y definición de una contraseña.<br />

                                El usuario puede elegir y cambiar la clave para su acceso de administración de la cuenta en cualquier momento, en caso de que se haya registrado y que sea necesario para la compra de alguno de nuestros productos. No asume la responsabilidad en caso de que entregue dicha clave a terceros.<br />

                                Todas las compras y transacciones que se lleven a cabo por medio de este sitio web, están sujetas a un proceso de confirmación y verificación, el cual podría incluir la verificación del stock y disponibilidad de producto, validación de la forma de pago, validación de la factura (en caso de existir) y el cumplimiento de las condiciones requeridas por el medio de pago seleccionado. En algunos casos puede que se requiera una verificación por medio de correo electrónico.<br />
                                El usuario puede elegir y cambiar la clave para su acceso de administración de la cuenta en cualquier momento, en caso de que se haya registrado y que sea necesario para la compra de alguno de nuestros productos. No asume la responsabilidad en caso de que entregue dicha clave a terceros.<br />

                                Todas las compras y transacciones que se lleven a cabo por medio de este sitio web, están sujetas a un proceso de confirmación y verificación, el cual podría incluir la verificación del stock y disponibilidad de producto, validación de la forma de pago, validación de la factura (en caso de existir) y el cumplimiento de las condiciones requeridas por el medio de pago seleccionado. En algunos casos puede que se requiera una verificación por medio de correo electrónico.<br />

                                Los precios de los productos ofrecidos en esta Tienda Online es válido solamente en las compras realizadas en este sitio web.
                            </>

                        </Typography>

                    </Grid>
                </Grid>
            </Paper>
        </>
    );
}

export default TerminosCondiciones;
