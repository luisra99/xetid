import TerminosCondiciones from './TerminosCondiciones';

export default TerminosCondiciones;
