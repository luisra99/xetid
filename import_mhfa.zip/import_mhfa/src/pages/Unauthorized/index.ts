import Unauthorized from './Unauthorized';

export default Unauthorized;
