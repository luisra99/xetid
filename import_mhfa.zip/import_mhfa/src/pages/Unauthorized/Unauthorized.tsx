import { Box } from '@mui/material';
import Typography from '@mui/material/Typography';

import Meta from '@/shared/components/Meta';

function Unauthorized() {
  return (
    <>
      <Meta title="page 4" />
      <Box p={3}>
        <Typography variant="h5">Usted no esta autorizado a acceder a este sitio.</Typography>
        <Typography variant="h6">
          Si piensa que esto es un error, contacte al administrador del sistema.
        </Typography>
      </Box>
    </>
  );
}
export default Unauthorized;
