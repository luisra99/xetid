import Importar from './Importar';

export default Importar;
