import './Welcome.sass';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import QueryStatsIcon from '@mui/icons-material/QueryStats';
import AnalyticsIcon from '@mui/icons-material/Analytics';
import { Grid, Paper } from '@mui/material';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import useTheme from '@/store/theme';
import Meta from '@/shared/components/Meta';
import { Themes } from '@/theme/types';

function Welcome() {
  const [theme,] = useTheme()
  const headerColor = theme == Themes.DARK ? 'rgb(240, 240, 240)' : 'rgb(0, 145, 205)'
  const iconShadows = theme == Themes.DARK ? "drop-shadow(0px 1px 5px rgb(62, 112, 166))" : 'none'
  const iconColor = theme == Themes.DARK ? 'inherit' : 'rgb(0, 145, 205);'
  return (
    <>
      <Meta title="Inicio" />
      <Box className="welcome" style={{ textAlign: 'center' }} >
        <Grid container p={2} minHeight={'97vh'}>
          <Grid item md={6} lg={6} xl={3} sx={{ display: { xs: 'none', sm: 'none', md: 'none', lg: 'block' } }} m={'auto'}>
            <img style={{ maxHeight: '80%', maxWidth: '100%', filter: 'drop-shadow(2px 2px 3px #182837)' }} src="/welcome.webp"></img>
          </Grid>
          <Grid item md={12} lg={6} xl={9} m={'auto'}>
            <Typography
              sx={{ textAlign: 'center', color: headerColor, fontSize: { xs: '2.5rem', sm: '2.5rem', md: '3rem', lg: '3rem', xl: '5rem' }, display: { xs: 'none', sm: 'block' } }}
              variant='h2'
              my={4}
            >
              React PWA Template
            </Typography>
          </Grid>
        </Grid>
      </Box>
    </>
  );
}

export default Welcome;
