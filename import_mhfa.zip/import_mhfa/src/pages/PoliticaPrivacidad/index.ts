import PoliticaPrivacidad from './PoliticaPrivacidad';

export default PoliticaPrivacidad;
