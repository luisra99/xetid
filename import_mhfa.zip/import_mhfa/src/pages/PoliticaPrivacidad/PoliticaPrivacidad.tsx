
import { Grid } from '@mui/material';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Meta from '@/shared/components/Meta';
import Paper from '@mui/material/Paper';

function PoliticaPrivacidad() {
    return (
        <>
            <Meta title="Politica de Privacidad" />

            <Paper
                sx={{
                    p: 2,
                    margin: 'auto',
                    borderRadius: '10px',
                    maxWidth: '95vw',
                    marginTop: '10vh'
                }}
            >
                <Grid container p={2}>
                    <Grid item xs={12}  >
                        <Typography variant="subtitle1" textAlign='center' component="div" sx={{ fontWeight: 'bold', fontSize: '18px' }}>
                            Politica de Privacidad
                        </Typography>
                        <Typography variant="subtitle1" textAlign='center' component="div" sx={{ fontSize: '10px', fontWeight: 'bold', marginTop: 2 }}>
                            <>
                                (El siguiente texto no está vigente, solo se muestra temporalmente  en lo que se  elabora el ducumento oficial.)
                            </>
                        </Typography>
                        <Typography variant="subtitle1" textAlign='justify' component="div" sx={{ fontSize: '15px', marginTop: 3 }}>
                            <>
                                De manera genérica a continuación se entrega un texto guía para la elaboración de
                                la política general de seguridad de la información, este puede ser base del desarrollo
                                de dicho documento ya que contempla los principios básicos a tener en cuenta en
                                su elaboración dentro de la planeación del sistema de gestión de seguridad de la
                                información en una entidad.<br />
                                La dirección de NOMBRE DE LA ENTIDAD, entendiendo la importancia de una
                                adecuada gestión de la información, se ha comprometido con la implementación
                                de un sistema de gestión de seguridad de la información buscando establecer un
                                marco de confianza en el ejercicio de sus deberes con el Estado y los ciudadanos,
                                todo enmarcado en el estricto cumplimiento de las leyes y en concordancia con
                                la misión y visión de la entidad.<br />
                                Para NOMBRE DE LA ENTIDAD, la protección de la información busca la
                                disminución del impacto generado sobre sus activos, por los riesgos identificados
                                de manera sistemática con objeto de mantener un nivel de exposición que
                                permita responder por la integridad, confidencialidad y la disponibilidad de la
                                misma, acorde con las necesidades de los diferentes grupos de interés
                                identificados.<br />
                                De acuerdo con lo anterior, esta política aplica a la Entidad según como se defina
                                en el alcance, sus funcionarios, terceros, aprendices, practicantes, proveedores
                                y la ciudadanía en general, teniendo en cuenta que los principios sobre los que
                                se basa el desarrollo de las acciones o toma de decisiones alrededor del SGSI
                                estarán determinadas por las siguientes premisas:<br />
                                •	 Minimizar el riesgo en las funciones más importantes de la entidad.<br />
                                •	 Cumplir con los principios de seguridad de la información.<br />
                                •	 Cumplir con los principios de la función administrativa.<br />
                                •	 Mantener la confianza de sus clientes, socios y empleados.<br />
                                •	 Apoyar la innovación tecnológica.<br />
                                •	 Proteger los activos tecnológicos.<br />
                                •	Establecer las políticas, procedimientos e instructivos en materia de<br />
                                seguridad de la información.<br />
                                •	Fortalecer la cultura de seguridad de la información en los funcionarios,
                                terceros, aprendices, practicantes y clientes de NOMBRE DE LA ENTIDAD.<br />
                                •	Garantizar la continuidad del negocio frente a incidentes.<br />
                                •	NOMBRE DE LA ENTIDAD ha decidido definir, implementar, operar y
                                mejorar de forma continua un Sistema de Gestión de Seguridad de la
                                Información, soportado en lineamientos claros alineados a las
                                necesidades del negocio, y a los requerimientos regulatorios.<br />

                            </>

                        </Typography>

                    </Grid>
                </Grid>
            </Paper>
        </>
    );
}

export default PoliticaPrivacidad;
