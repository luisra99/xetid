import welcome from '@/utils/welcome';

Promise.all([import('@/Root'), import('@/App')]).then(([{ default: render }, { default: App }]) => {
  //navigator.serviceWorker.register('sw.js', { scope: '/', type: 'module' });
  render(App);
});

// welcome message for users in the console
welcome();

// ts(1208)
export {};
