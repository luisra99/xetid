import axios from 'axios';
import { FAQS } from '@/shared/interfaces/common';
import { apiScope } from '@/config';

const preguntas = [
    {
        pregunta: '¿Cómo inicio sesión en mi cuenta?',
        respuesta: "La plataforma en la que estás intentando iniciar sesión, utiliza ..."
    }
]

export async function GetPreguntasFrecuentes(): Promise<FAQS[]> {

    try {
        return preguntas;
        const response = await axios.get(
            `${import.meta.env.VITE_SERVER_URL}${apiScope
            }notificaciones`,
        );
        const FAQS = response.data;
        return FAQS;
    } catch (error) {
        console.error('Error consuming API', error);
        return [];
    }
}
