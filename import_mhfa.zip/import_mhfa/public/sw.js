self.addEventListener('activate', function (event) {
  event.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (key) {
      return !cacheIDs.includes(key);
		}).map(function (key) {
      if(!/\b(workbox)\b/.test(key))
      return caches.delete(key);
		}));
	}));
});

import { clientsClaim } from 'workbox-core';
import { precacheAndRoute } from 'workbox-precaching';
import { registerRoute } from 'workbox-routing';
import { StaleWhileRevalidate, CacheFirst, NetworkFirst } from 'workbox-strategies';

self.__WB_MANIFEST;

const version = 'v0.1';
const coreID = version + '_core';
const pageID = version + '_pages';
const imgID = version + '_assets';
const apiID = version + '_api';
const apiM =version+ '_apim';
const cacheIDs = [coreID, pageID, imgID,apiID,apiM];

precacheAndRoute(self.__WB_MANIFEST);
self.skipWaiting();
clientsClaim();

registerRoute(
  /.*\.(png|jpg|jpeg|svg|gif|webp|css)/,
  new CacheFirst({
    cacheName: imgID,
  }),
);

registerRoute(
  /.*\/api\/.*/,
  new NetworkFirst({
    cacheName: apiID,
  }),
);

registerRoute(
  /(?!.*index.*.js$).*\/.*/,
  new StaleWhileRevalidate({
    cacheName: coreID,
  }),
);
